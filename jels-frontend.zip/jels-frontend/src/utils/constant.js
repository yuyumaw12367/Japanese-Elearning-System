const localDomain = "http://localhost:8082";
const get_knowledge_url = localDomain+'/knowledge/all';
const read_file=localDomain+'/admin/file/load/';

const test = "test";

export default { localDomain, test,get_knowledge_url ,read_file,};
